class Metric(object):

    FRACTIONAL   = False
    ACCUMULATIVE = False

    def set_expected(self, expected):
        self.expected = expected

